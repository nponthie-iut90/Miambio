from flask import Flask, request, render_template, redirect, url_for, abort, flash

app = Flask(__name__)
app.secret_key = 'une cle(token) : grain de sel(any random string)'

from flask import session, g
import pymysql.cursors

# mysql --user=agaiffe2 --password=mdp --host=serveurmysql BDD_agaiffe2

def get_db():
    if 'db' not in g:
        g.db =  pymysql.connect(
            host="serveurmysql",                 # à modifier
            user="agaiffe2",                     # à modifier
            password="mdp",                # à modifier
            database="BDD_agaiffe2",        # à modifier
            charset='utf8mb4',
            cursorclass=pymysql.cursors.DictCursor
        )
    return g.db



@app.route('/')
def show_layout():
    return render_template('layout.html')


if __name__ == '__main__':
    app.run()

@app.route('/')
@app.route('/recolte/show')
def show_recolte():
    mycursor = get_db().cursor()
    sql='''
 SELECT  Id_Récolte AS id,  Quantite_recoltee AS qtRecolte, Id_Semaine AS semaine, Id_produit AS id_produit, Id_Maraicher AS id_maraicher
 FROM recolte
    ORDER BY id;
    '''
    mycursor.execute(sql)
    recoltes = mycursor.fetchall()
    return render_template('recolte/show_recolte.html', recoltes=recoltes)

@app.route('/recolte/add', methods=['GET'])
def add_recolte():
    print('''affichage du formulaire pour saisir une récolte''')
    return render_template('recolte/add_recolte.html')

@app.route('/recolte/delete')
def delete_recolte():
    print('''suppression d'un étudiant''')
    id=request.args.get('id',0)
    print(id)
    mycursor = get_db().cursor()
    tuple_param=(id)
    sql="DELETE FROM etudiant WHERE id_etudiant=%s;"
    mycursor.execute(sql,tuple_param)

    get_db().commit()
    print(request.args)
    print(request.args.get('id'))
    id=request.args.get('id',0)
    return redirect('/recolte/show')

@app.route('/recolte/edit', methods=['GET'])
def edit_recolte():
    print('''affichage du formulaire pour modifier un étudiant''')
    print(request.args)
    print(request.args.get('id'))
    id=request.args.get('id')
    mycursor = get_db().cursor()
    sql=''' SELECT id_etudiant AS id, nom_etudiant AS nom, groupe_etudiant AS groupe
    FROM etudiant
    WHERE id_etudiant=%s;'''
    tuple_param=(id)
    mycursor.execute(sql,tuple_param)
    etudiant = mycursor.fetchone()
    return render_template('recolte/edit_recolte.html', etudiant=etudiant)


@app.route('/etudiant/add', methods=['POST'])
def valid_add_recolte():
    print('''ajout de l'étudiant dans le tableau''')
    nom = request.form.get('nom')
    groupe = request.form.get('groupe')
    message = 'nom :' + nom + ' - groupe :' + groupe
    print(message)
    mycursor = get_db().cursor()
    tuple_param=(nom,groupe)
    sql="INSERT INTO etudiant(id_etudiant, nom_etudiant, groupe_etudiant) VALUES (NULL, %s, %s);"
    mycursor.execute(sql,tuple_param)
    get_db().commit()
    return redirect('/recolte/show')

@app.route('/etudiant/edit', methods=['POST'])
def valid_edit_recolte():
    print('''modification de l'étudiant dans le tableau''')
    id = request.form.get('id')
    nom = request.form.get('nom')
    groupe = request.form.get('groupe')
    message = 'nom :' + nom + ' - groupe :' + groupe + ' pour l etudiant d identifiant :' + id
    print(message)
    mycursor = get_db().cursor()
    tuple_param=(nom,groupe,id)
    sql="UPDATE etudiant SET nom_etudiant = %s, groupe_etudiant= %s WHERE id_etudiant=%s;"
    mycursor.execute(sql,tuple_param)
    get_db().commit()
    return redirect('/recolte/show')

